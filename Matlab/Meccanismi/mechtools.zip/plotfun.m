function plotfun(fun,x)


y=fun(x);

plot(x,y);